const logoImg = document.querySelector('img');
const button = document.querySelector('button');
const heading = document.querySelector('h1');
logoImg.addEventListener("click", function () {
    if(logoImg.getAttribute('src') == 'img/img1.png'){
        logoImg.setAttribute('src', 'img/img2.png');
    }else{
        logoImg.setAttribute('src', 'img/img1.png');
    }
});

button.addEventListener("click", function () {
    let name = prompt("What is your name?", "Type your name..");
    heading.textContent = `Welcome ${name}!`;
})

